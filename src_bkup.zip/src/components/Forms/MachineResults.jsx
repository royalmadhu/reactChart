import React from 'react'

function MachineResults({mydata}) {
  return (
    <div>MachineResults</div>
  )
}

export default MachineResults