import React from 'react'

function DataSummary() {
  return (
    <div>DataSummary</div>
  )
}

export default DataSummary