import React, { useState } from "react";

function Sidebar({ onSelectOption }) {
  const [selectedOption, setSelectedOption] = useState("");

  const handleClick = (option) => {
    setSelectedOption(option);
    onSelectOption(option);
  };

  return (
    <div className="sidebar">
      <h2 className="text-2xl mt-16 ml-8 font-medium">Menu</h2>
      <ul className="ml-8 mt-4">
        <li onClick={() => handleClick("uploadForm")} className="cursor-pointer mb-2 font-normal">Dashboard</li>
        <li onClick={() => handleClick("dataSummary")} className="cursor-pointer">Data Summary</li>
        <li onClick={() => handleClick("results")} className="cursor-pointer mt-2">Results</li>
      </ul>
    </div>
  );
}

export default Sidebar;
