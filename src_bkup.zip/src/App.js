import React, { useState } from "react";
import "./App.css";
import "./style.css";
import UploadForm from "./components/Forms/UploadForm";
import DataSummary from "./components/DataSummary";
import Results from "./components/Results";
import Sidebar from "./components/Sidebar";
import Xldata from "./components/Xldata";

function App() {
  const [selectedOption, setSelectedOption] = useState("uploadForm");
  const [resultData, setResultData] = useState(null);

  const handleDataUpload = (data) => {
    setResultData(data);
  };
  const handleSelectOption = (option) => {
    setSelectedOption(option);
  };

  return (
    <div className="App">
      <Sidebar onSelectOption={handleSelectOption} />
      <div className="content">
        {/* <Xldata /> */}
        {resultData ? (
          <Results data={resultData} />
        ) : (
          <UploadForm onDataUpload={handleDataUpload} />
        )}
        {/* {selectedOption === "uploadForm" && <UploadForm />} */}
        {selectedOption === "dataSummary" && <DataSummary />}
        {selectedOption === "results" && <Results />}
      </div>
    </div>
  );
}

export default App;
